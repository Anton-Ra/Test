$(function() {

	$('.video-btn').hover(function(){//ф-я вывода кнопки наверх при заданной высоте экрана 
  	if ( $(".look").hasClass('dsn') )		{
  		$('.look').removeClass('dsn');
    } else{
      $('.look').addClass('dsn');
    }
  });


	$('.datepicker-here').datepicker({
    navTitles: {
         days: 'MM'
    },
    showOtherMonths: false,
    prevHtml: '<i class="fa fa-angle-left" aria-hidden="true"></i>',
    nextHtml: '<i class="fa fa-angle-right" aria-hidden="true"></i>'
    
})
	var eventDates = [14, 18, 27];
	var qwerty = [2, 3, 11, 12, 16, 17, 20, 22, 24, 30, 31];
		$('.datepicker-here').datepicker({

	    onRenderCell: function(date, cellType) {
	    		var currentDate = date.getDate();
	        if (cellType == 'day' && qwerty.indexOf(currentDate) != -1) {
	            return {
	                classes: 'bgc-green',
	                disabled: true
	            }
	        }
					if (cellType == 'day' && eventDates.indexOf(currentDate) != -1) {
		            return {
		              classes: 'bgc-red',
	                disabled: true
		            }
		    }
		  }
	});
	
		

});

$(document).ready(function() {
  $('.popup-youtube').magnificPopup({
		disableOn: 700,
		type: 'iframe',
		mainClass: 'mfp-fade',
		removalDelay: 160,
		preloader: false,

		fixedContentPos: false
	});
});
